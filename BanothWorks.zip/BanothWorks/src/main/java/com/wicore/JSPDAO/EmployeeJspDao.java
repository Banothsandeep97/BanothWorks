package com.wicore.JSPDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import com.wicore.bean.EmployeeJsp;
public class EmployeeJspDao {
	public static void EmployeeInsetInto(EmployeeJsp emp, Connection con) throws SQLException {
		try {
			PreparedStatement ss = null;
			ss = con.prepareStatement("INSERT INTO empjspdata(name,email,phone_no,State,Adress,gender,Designation)" + "values(?,?,?,?,?,?,?)");

			ss.setString(1, emp.getName());
			ss.setString(2, emp.getEmail());
			ss.setString(3, emp.getPhone_no());
			ss.setString(4, emp.getState());
			ss.setString(5, emp.getAdress());
			ss.setString(6, emp.getGender());
			ss.setString(7, emp.getDesignation());
			int i = ss.executeUpdate();
			if (i > 0) {
				System.out.println("added");
			} else {
				System.out.println("Failed to added");
			}
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*public static void getemployee( EmployeeJsp emp, Connection con) {
		  
		PreparedStatement st= null;
		ResultSet rs=null;
		try {
		  String query = "select Emp_id,name,email,phone_no,State,Adress,gender,"
		  		+ "Designation from emp";
		    st=con.prepareStatement(query);
		     rs=st.executeQuery();
			//Statement st= con.createStatement();
			//out.print("<table width=50% border=1>");
			//out.print("<caption>Result:</caption>");
			//ResultSet rs = st.executeQuery("select * from emp");
		  while(rs.next()) {
			  int emp_id = rs.getInt("Emp_id");
			String name= rs.getString("name");
			String email=rs.getString("email");
			String phone_no=rs.getString("phone_no");
			String State = rs.getString("State");
			String Adress=rs.getString("Adress");
			String gender =rs.getString("gender");
			String Designation=rs.getString("Designation");
			
			//System.out.println(name+"\n"+email+"\n"+phone_no+"\n"+State+"\n"+Adress+"\n"+gender+"\n"+Designation);
		  }
		  
		  }
		catch(SQLException e) {
			e.printStackTrace();
		}catch(Exception e) {
			  e.printStackTrace();
		  }
	  }
	/*public static void update( Employee emp, Connection con) {
		
		try {
			
			String updQry = "update emp set name = '"+"', email = '"+"', phone_no = '"+"', State = '"+"', Adress = '"+"', gender = '"+"', Designation = '"+"' where Emp_id = '"+"'";
			//Connection con = ConnectionDAO.getcon();
			//Employee emp= new Employee();
			PreparedStatement pst = null;
			//String query = "select Emp_id,name,email,phone_no,State,Adress,gender,Designation from emp"+"where id =?";
			pst=con.prepareStatement(updQry);
		     //rs=st.executeQuery();
		    pst.setString(1, emp.getName());
			pst.setString(2, emp.getEmail());
			pst.setString(3, emp.getPhone_no());
			pst.setString(4, emp.getState());
			pst.setString(5, emp.getAdress());
			pst.setString(6, emp.getGender());
			pst.setString(7, emp.getDesignation());
			pst.setInt(8, emp.getEmp_id());
			int row = pst.executeUpdate();
			if (row > 0) {
				System.out.println("updated");
			} else {
				System.out.println("Failed to updataed");
			}
			row = pst.executeUpdate();
            System.out.println(String.format("Row affected %d", row));
		}catch(Exception e) {
			
			e.printStackTrace();
			
		}
	}*/

}
