package com.wicore.JSPDAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class ConnectionLogin {
	static Connection con = null;
	 public static Connection getcon(){
		try {
			//Class driver_class = Class.forName("com.mysql.jdbc.Driver");
           //Driver driver = (Driver) driver_class.newInstance();
          // DriverManager.registerDriver(driver);
			Class.forName("com.mysql.jdbc.Driver").newInstance();
	        //con = DriverManager.getConnection("jdbc:mysql://localhost:3306/empjsp", "root", "Mysql@123");
           // con = DriverManager.getConnection("jdbc:mysql://202.65.157.186:3306/winscp1", "cms", "Samsung@w1c0r3");
			con = DriverManager.getConnection("jdbc:mysql://sql12.freesqldatabase.com:3306/sql12667347", "sql12667347", "Ms2FdBR7fS");
			System.out.println("Connection Created ...........:"+con);
		}
		catch(ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		
		catch (IllegalAccessException e) {
           e.printStackTrace();
       } catch (InstantiationException e) {
           e.printStackTrace();
       }
		catch(Exception e) {
			e.printStackTrace();
			System.out.println("Exception "+ e);
		}
		 return con;   
	 }
	 public static Connection closecon() {
		try {
			if(con != null)
				con.close();
			System.out.println("Connection close ............");
		} 
		catch(Exception e) {
			e.printStackTrace();
		}
		 return con;
	 }
	 

}

